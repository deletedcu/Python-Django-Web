# The goal of today's olympics is to analyze flask files!  So fun!!!

# You should be able to see the file tree, and the templates and the server as well as any other files that might be required and determine whether we'll get an error or proper rendering/response!
Good Luck!

