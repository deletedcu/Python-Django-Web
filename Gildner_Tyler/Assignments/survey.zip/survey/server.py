from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'Thisissecret'
@app.route('/')
def index():
  return render_template("index.html")
@app.route('/users', methods=['POST'])
def create_user():
   print "Got Post Info"
   # here we add two properties to session to store the name and email
   session['name'] = request.form['name']
   session['comment'] = request.form['comment']
   session['favorite_language'] = request.form['favorite_language']
   session['dojo_select'] = request.form['dojo_select']
   return redirect('/show') # redirects back to the '/' route
@app.route('/show')
def show_user():
  return render_template('user.html')
app.run(debug=True)
