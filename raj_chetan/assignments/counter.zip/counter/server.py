from flask import Flask, render_template, request, session, redirect 
app = Flask(__name__)
app.secret_key = "thisisthesecretkey"


@app.route('/')
def index():
	if not 'counter' in session:
		session['counter'] = 0
	session['counter'] +=1
	return render_template("index.html")

@app.route('/process', methods=['POST'])
def process():
	if request.form['action'] == 'double_me':
		session['counter'] += 1
	elif request.form['action'] == 'clear_me':
		session['counter'] = -1

	return redirect('/')
app.run(debug=True)