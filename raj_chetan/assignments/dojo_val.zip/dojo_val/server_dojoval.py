from flask import Flask, render_template, request, redirect, session, flash
import re 

app = Flask(__name__)
app.secret_key = "SecretKeyz"

email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
name_regex = re.compile(r'^[a-zA-Z]+$')


@app.route('/')
def index():
	if 'first_name' not in session:
		session['first_name'] = ''
	if 'last_name' not in session:
		session['last_name'] = ''
	if 'email' not in session:
		session['email'] = ''
	if 'password' not in session:
		session['password'] = ''
	if 'confirm_password' not in session:
		session['confirm_password'] = ''
	return render_template("index.html")

@app.route('/results', methods=['POST'])
def show_results():
	print "Server has received user input."
	session.clear()

	if len(request.form['first_name']) < 1:
		flash("FIRST NAME NOT ENTERED") 
		print "too few char first name"
		#return redirect('/')
	elif name_regex.match(request.form['first_name']): 
		session['first_name'] = request.form['first_name']
	else: 
		flash("FIRST NAME CAN ONLY CONTAIN LETTERS")

	if len(request.form['last_name']) < 1:
		flash("LAST NAME NOT ENTERED") 
		print "too few char last name"
		#return redirect('/')
	elif name_regex.match(request.form['last_name']): 
		session['last_name'] = request.form['last_name']
	else: 
		flash("LAST NAME CAN ONLY CONTAIN LETTERS")

	if len(request.form['email']) < 1:
		flash("MUST ENTER EMAIL") 
		print "TOO FEW EMAIL"
		#return redirect('/')
	elif email_regex.match(request.form['email']):
		session['email'] = request.form['email']
	else:
		flash('INVALID EMAIL ADDRESS')

	if len(request.form['password']) < 8 or request.form['password'] != request.form['confirm_password']:
		flash("Invalid PW!")
	else:
		session['password'] = request.form['password']		

	#session['first_name'] = request.form['first_name']
	return redirect('/')

@app.route('/show')
def show_user():
	return render_template('user.html')
app.run(debug=True)