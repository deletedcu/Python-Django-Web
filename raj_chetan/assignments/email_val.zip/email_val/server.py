from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
import datetime

app = Flask(__name__)
mysql = MySQLConnector(app, 'emailsdb')
app.secret_key = "thisissecret"

email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.+_-]+\.[a-zA-Z]+$')

@app.route('/')
def index():
	select_all_query = "SELECT * FROM email"
	list_of_addresses = mysql.query_db(select_all_query)
	return render_template('index.html', list_of_addresses = list_of_addresses)

@app.route('/add_email', methods = ['POST'])
def add_email():
	unverified_email = request.form['email']

	if email_regex.match(unverified_email):
		verified_email = unverified_email
		query = "INSERT INTO email (address, created_at) VALUES (:valid_address, NOW())"
		data = {'valid_address': verified_email}
		mysql.query_db(query, data)
		flash("You successfully entered the email address {} at {}".format(verified_email, datetime.datetime.now()))
		return redirect ('/')
	else: 
		flash("There is an error with your email address")
		return redirect ('/')

@app.route('/delete/<int:id>')
def delete(id):
	query = "DELETE FROM email WHERE id = :id"
	data = {'id': id}
	mysql.query_db(query, data)
	flash("The email address ID {} has been deleted".format(id))
	return redirect('/')
	# if verified_email:
	# 	query = "INSERT INTO email (address) VALUES (:valid_address)"
	# 	data = {'valid_address': verified_email}
	# 	mysql.query_db(query, data)
	# return redirect('/')


app.run(debug=True)