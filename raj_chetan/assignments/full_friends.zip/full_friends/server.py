from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector
import re
import datetime

app = Flask(__name__)
mysql = MySQLConnector(app, 'fullfriends')
app.secret_key = 'thisismysecretkey'

name_regex = re.compile(r'^[A-Za-z]+$')
email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.+_-]+\.[a-zA-Z]+$')

@app.route('/')
def index():
	select_all_query = "SELECT * from friends"
	list_of_friends = mysql.query_db(select_all_query)
	return render_template('index.html', list_of_friends = list_of_friends)

@app.route('/friends', methods=['POST'])
def create():
	unverified_email = request.form['email']
	unverified_first_name = request.form['first_name']
	unverfied_last_name = request.form['last_name']
	valid = True
	if email_regex.match(unverified_email):
		verified_email = unverified_email
	else:
		valid = False
		flash("Email address is not valid")
	if name_regex.match(unverified_first_name):
		verified_first_name = unverified_first_name
	else: 
		valid = False
		flash("First name is not valid")
	if name_regex.match(unverfied_last_name):
		verified_last_name = unverfied_last_name
	else:
		flash("Last name is not valid")
		valid = False
	if valid:
		query = "INSERT INTO friends (first_name, last_name, email, created_at) VALUES (:first_name, :last_name, :email, NOW())"
		data = {
				'first_name': verified_first_name,
				'last_name': verified_last_name,
				'email': verified_email
		}
		mysql.query_db(query, data)
		flash("Friend {} {} successfully added to database at {}".format(verified_first_name, verified_last_name, datetime.datetime.now()))
		return redirect ('/')
	else:
		return redirect('/')

@app.route('/friends/<id>/edit')
def edit(id):
	currently_editing = "SELECT * FROM friends WHERE id = {}".format(id)
	editing_who_raw = mysql.query_db(currently_editing)
	print editing_who_raw
	return render_template('edit.html', id = id, editing_who_raw = editing_who_raw)

@app.route('/friends/<id>', methods = ['POST'])
def updated(id):
	unverified_email = request.form['new_email']
	unverified_first_name = request.form['new_first']
	unverfied_last_name = request.form['new_last']
	valid = True
	if email_regex.match(unverified_email):
		verified_email = unverified_email
	else:
		valid = False
		flash("Email address is not valid")
	if name_regex.match(unverified_first_name):
		verified_first_name = unverified_first_name
	else: 
		valid = False
		flash("First name is not valid")
	if name_regex.match(unverfied_last_name):
		verified_last_name = unverfied_last_name
	else:
		flash("Last name is not valid")
		valid = False
	if valid:
		query = "UPDATE friends SET first_name = :first_name, last_name = :last_name, created_at = NOW() WHERE id = {}".format(id)
		data = {
				'first_name': unverified_first_name,
				'last_name': unverfied_last_name,
				'email': unverified_email
		}
		mysql.query_db(query, data)
		return redirect ('/')
	else:
		return redirect('/friends/{}/edit'.format(id))	

@app.route('/friends/<userid>/delete', methods = ['POST'])
def destory(userid):
	del_query = "DELETE FROM friends WHERE id = {}".format(userid)
	mysql.query_db(del_query)
	print userid
	return redirect('/')
app.run(debug=True)