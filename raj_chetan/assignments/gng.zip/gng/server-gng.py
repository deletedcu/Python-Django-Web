from flask import Flask, render_template, session, redirect, request
import random

app = Flask(__name__)
app.secret_key = 'asjdfjea;ksdjf'

@app.route('/')
def index():
	if 'reset' in session and session['reset'] == True:
		print 'weird index condition met...'
		session.pop('conditional_text')
		session.pop('secret')
		session['variable_class'] = 'purple'
		session['reset'] = False
	if not 'secret' in session:
		session['secret'] = random.randint(1,100)
	if not 'user_input' in session:
		session['user_input'] = 'does not exist'
	if not 'variable_class' in session:
		session['variable_class'] = 'purple'
	if not 'conditional_text' in session:
		session['conditional_text'] = ""
	return render_template('index.html')

@app.route("/process", methods = ['POST'])
def process_page():
	session['user_input'] = int(request.form['user_input'])
	if session['user_input'] == session['secret']:
		session['variable_class'] = 'green'
		session['conditional_text'] = 'you guessed correct! enter a new number to reset the game and play again!'
		session['reset'] = True
		print 'reached == condition'
		return redirect('/')
	elif session['user_input'] > session['secret']:
		session['variable_class'] = 'red'
		session['conditional_text'] = 'you guessed too high!'
		print 'reached high condition'
		return redirect('/')
	elif session['user_input'] < session['secret']:
		session['variable_class'] = 'red'
		session['conditional_text'] = 'you guessed too low!'
		print 'reached low condition'
		return redirect('/')
	else:
		return redirect('/')
	
app.run(debug=True)