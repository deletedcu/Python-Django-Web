from flask import Flask, request, redirect, render_template, session, flash
from mysqlconnection import MySQLConnector 
import re
from flask_bcrypt import Bcrypt
import datetime 

app = Flask(__name__)
mysql = MySQLConnector(app, 'loginandregistration')
app.secret_key = 'secretkey123'
bcrypt = Bcrypt(app)

name_regex = re.compile(r'^[A-Za-z]+$')
email_regex = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9.+_-]+\.[a-zA-Z]+$')

@app.route('/')
def index():
	all_results = mysql.query_db("SELECT * from users")
	return render_template('index.html', all_results = all_results)


@app.route('/process', methods = ['POST'])
def process():
	if 'logout_hidden' in request.form:
		session.clear()
		return redirect('/')

	if 'registration_hidden' in request.form:
		unverified_email = request.form['email']
		unverified_first_name = request.form['first_name']
		unverfied_last_name = request.form['last_name']
		valid = True
		if email_regex.match(unverified_email):
			verified_email = unverified_email
		else:
			valid = False
			flash("Email address is not valid")
		if name_regex.match(unverified_first_name) and (len(unverified_first_name) > 2):
			verified_first_name = unverified_first_name
		else: 
			valid = False
			flash("First name is not valid")
		if name_regex.match(unverfied_last_name) and (len(unverified_first_name) > 2):
			verified_last_name = unverfied_last_name
		else:
			flash("Last name is not valid")
			valid = False
		if (request.form['password'] == request.form['confirm']) and (len(request.form['password']) > 8):
			plain_text_pw = request.form['password']
			encrypted_pw = bcrypt.generate_password_hash(plain_text_pw)
		else:
			valid = False
			flash("Password entry error.")

		if valid:
			query = "INSERT INTO users (first_name, last_name, email, password, plaintextpw, created_at) VALUES (:first_name, :last_name, :email, :password, :plaintextpw, NOW())"
			data = {
				'first_name': verified_first_name,
				'last_name': verified_last_name,
				'email': verified_email,
				'password': encrypted_pw,
				'plaintextpw': plain_text_pw
				}
			mysql.query_db(query, data)
			flash("User {} {} successfully added to database at {}".format(verified_first_name, verified_last_name, datetime.datetime.now()))
			return redirect ('/')
		else:
			return redirect('/')
	if 'login_hidden' in request.form:
		passed_email = request.form['email']
		passed_password = request.form['password']
		user_query = "SELECT * FROM users WHERE email = :email LIMIT 1"
		data_query = {'email': passed_email}
		user_checkout = mysql.query_db(user_query, data_query)
		if bcrypt.check_password_hash(user_checkout[0]['password'], passed_password):
			flash("You have successfully logged in")
			session['id'] = user_checkout[0]['id']
			print session['id']
			return redirect('/success')
		else:
			flash("Your login credentials are invalid.")
			return redirect('/')

@app.route('/success')
def success():
	query = "SELECT * FROM users WHERE users.id = {}".format(session['id'])
	user_info = mysql.query_db(query)
	return render_template('success.html', user_info = user_info)
app.run(debug=True)