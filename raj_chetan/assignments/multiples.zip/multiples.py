for var in range(1000):
	if var%2 != 0:
		print var
