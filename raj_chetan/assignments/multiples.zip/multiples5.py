for var in range(5,100):
	if var%5==0:
		print var