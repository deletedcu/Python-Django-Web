from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')

# @app.route('/users/<username>')
# def show_user_profile(username):
#     return render_template("user.html", username=username)

@app.route('/ninja')
def ninja():
	return render_template('ninja.html')

@app.route('/ninja/<color>')
def each_ninja(color):
	passed = "{{url_for('static', filename='images/"+color+".jpg')}}"
	if color == 'blue' or 'red' or 'purple' or 'orange':
		pass
	else:
		color = 'notapril'
	return render_template('each.html', color = color, passed = passed)

app.run(debug=True)