from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route('/')
def index():
	return render_template('index.html')

# @app.route('/users/<username>')
# def show_user_profile(username):
#     return render_template("user.html", username=username)

@app.route('/ninja')
def ninja():
	return render_template('ninja.html')

@app.route('/ninja/<color>')
def each_ninja(color):
	if color == 'blue' or color == 'red' or color =='purple' or color == 'orange':
		to_pass = color
	else:
		to_pass = 'notapril'
	passed = url_for('static', filename='images/'+to_pass+'.jpg')	
	return render_template('each.html', color = color, passed = passed, to_pass = to_pass)

app.run(debug=True)